package labmatr7413.avgor.lab_matr;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerSizeSystem;
    LinearLayout systemLinearLayout;
    LinearLayout matrixGaussLinearLayout;

    LinearLayout matrixTextAnswers;
    Context context;

    DrawSystem drawSystem;
    System system;
    Button buttonGauss;
    Button buttonDetailedGauss;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context =  getApplication().getApplicationContext();
        systemLinearLayout =  findViewById(R.id.linear_layout_system_picture);
        spinnerSizeSystem = findViewById(R.id.spinner_size_system);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, SizeSystem.SIZES_ARRAY_STRING);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        buttonGauss = findViewById(R.id.button_method_Gauss);
        buttonDetailedGauss = findViewById(R.id.button_detailed_method_Gauss);

        matrixGaussLinearLayout = findViewById(R.id.matrix_Gauss);

        matrixTextAnswers = findViewById(R.id.answer_Gauss);
        spinnerSizeSystem.setAdapter(adapter);
        spinnerSizeSystem.setSelection(0);

        SizeSystem.SIZES_ARRAY_STRING[0] = getString(R.string.select_value);

            buttonGauss.setOnClickListener(new View.OnClickListener() {
                @Override

                public void onClick(View v) {
                try {
                    system = new System(drawSystem.getIdEditTexts().length, drawSystem.getIdEditTexts()[0].length);
                    parseEditTexts(drawSystem);
                    MethodGauss methodGauss = new MethodGauss(system.systemCoefficients);
                    methodGauss.Gauss();
                    DrawMatrix drawMatrixGauss = new DrawMatrix(
                            context,
                            matrixGaussLinearLayout,
                            matrixTextAnswers,
                            methodGauss);
                    drawMatrixGauss.draw();
               }catch (Exception e){
                      ToastMessages.dataError(context);
                    }
                }

            });

            buttonDetailedGauss.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        system = new System(drawSystem.getIdEditTexts().length, drawSystem.getIdEditTexts()[0].length);
                        parseEditTexts(drawSystem);
                        MethodGauss methodGauss = new MethodGauss(system.systemCoefficients);
                        methodGauss.Gauss();
                        DrawMatrix drawMatrixGauss = new DrawMatrix(
                                context,
                                matrixGaussLinearLayout,
                                matrixTextAnswers,
                                methodGauss);
                        drawMatrixGauss.drawDetailed();
                    }catch (Exception e){
                        ToastMessages.dataError(context);
                    }
                }
            });

        spinnerSizeSystem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                   drawSystem = new DrawSystem(context, systemLinearLayout, position + 1);
                   if (position != 0) {drawSystem.draw();}
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    void parseEditTexts(DrawSystem drawSystem){
        for (int i = 0 ; i< system.getSystemCoefficients().length; i++){
            for (int j = 0 ; j< system.getSystemCoefficients()[0].length; j++){
                EditText editText = (EditText)findViewById(drawSystem.getIdEditTexts()[i][j]);
                Fraction fraction = new Fraction(Integer.parseInt(editText.getText().toString()), 1);
                system.setSystemCoefficients(fraction, i, j);
            }
        }
    }
}
