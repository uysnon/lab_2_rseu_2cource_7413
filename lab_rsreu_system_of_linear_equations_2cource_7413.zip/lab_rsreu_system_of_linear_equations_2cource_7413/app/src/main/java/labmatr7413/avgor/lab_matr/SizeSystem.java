package labmatr7413.avgor.lab_matr;

import java.lang.reflect.Array;

public class SizeSystem {

    public static String[]  SIZES_ARRAY_STRING  = new String[]
            {
                    "Определите значение",
                    "x1, x2",
                    "x1, x2, x3",
                    "x1, x2, x3, x4",
                    "x1, x2, x3, x4, x5 \n (*)"
            };
}
